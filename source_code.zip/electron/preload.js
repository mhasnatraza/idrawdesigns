window.addEventListener('DOMContentLoaded', () => {
    // Expose Node.js APIs if needed
});
