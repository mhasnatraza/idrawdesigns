import Canvas from './components/Canvas';
import AISidebar from './components/AISidebar';
import './App.css'

function App() {
  return (
    <div className="flex flex-col h-screen w-screen bg-[#0f172a] text-white overflow-hidden font-sans">
      {/* HEADER */}
      <header className="h-14 border-b border-white/5 bg-[#1e293b]/50 backdrop-blur-xl flex items-center px-4 justify-between z-10 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center font-bold text-lg">
            i
          </div>
          <span className="font-semibold tracking-wide text-sm text-slate-200">Draw Design</span>
        </div>

        <nav className="flex items-center gap-1 bg-[#0f172a]/50 p-1 rounded-lg border border-white/5">
          {/* Placeholder for toolbar tools */}
          <button className="px-3 py-1.5 text-xs font-medium bg-white/10 rounded text-white">Select</button>
          <button className="px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-white transition-colors">Rectangle</button>
          <button className="px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-white transition-colors">Circle</button>
          <button className="px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-white transition-colors">Text</button>
        </nav>

        <div className="w-8"></div> {/* Spacer balance */}
      </header>

      {/* WORKSPACE */}
      <div className="flex flex-1 overflow-hidden">
        {/* CANVAS AREA */}
        <Canvas />

        {/* SIDEBAR */}
        <AISidebar />
      </div>
    </div>
  )
}

export default App
